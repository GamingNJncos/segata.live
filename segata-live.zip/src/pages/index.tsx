import { AppWithAudioContextProvider } from "../containers/App";

export default function App() {
  return <AppWithAudioContextProvider />;
}
